﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace UnitOfWork
{
    public class Example
    {
        private readonly IUnitOfWorkManager manager;
        private readonly IGenericRepository<object> repository;

        public Example(IUnitOfWorkManager manager, IGenericRepository<object> repository)
        {
            this.manager = manager;
            this.repository = repository;
        }

        public async Task ExampleUseUnitOfWork()
        {
            using(var unitOfWork = manager.Create())
            {
                repository.AddOrUpdate(new object());
                await unitOfWork.SaveChangesAsync();
            }
        }

        public void WireUp() {
            //Register<>(
        }
    }
}
