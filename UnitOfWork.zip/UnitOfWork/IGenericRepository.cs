﻿using System.Linq;

namespace UnitOfWork
{
    public interface IGenericRepository<T>
    {
        IQueryable<T> DataSet { get; }
        void AddOrUpdate(T instance);
    }
}