﻿using System.Linq;

namespace UnitOfWork
{
    class EFGenericRepositoryExample<T> : IGenericRepository<T>
    {
        private readonly IUnitOfWorkManager manager;

        public EFGenericRepositoryExample(IUnitOfWorkManager manager)
        {
            this.manager = manager;
        }

        public IQueryable<T> DataSet
        {
            get
            {
                //var dbContext = manager.CurrentRepository as DBContext
                //return dbContext.Set<T>()
                return (new T[] { }).AsQueryable();
            }
        }

        public void AddOrUpdate(T instance)
        {
            //var dbContext = manager.CurrentRepository as DBContext
            //dbContext.AddOrUpdate(dbContext.Set<T>, instance)
        }
    }
}
