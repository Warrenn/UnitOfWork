﻿namespace UnitOfWork
{
    public interface IUnitOfWorkManager
    {
        IUnitOfWork Create();
        object CurrentRepository { get; }
    }
}
